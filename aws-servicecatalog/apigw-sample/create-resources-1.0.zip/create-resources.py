import json
import boto3
import os
import logging
from botocore.exceptions import ClientError
import requests

import snowflake.connector

SUCCESS = 'SUCCESS'
FAILED = 'FAILED'
EMPTY_RESPONSE_DATA = {}

EXTERNAL_ID = "external_id"
SERVICE = "service"
USER_ARN = "user_arn"

logger = logging.getLogger(__name__)
logger.setLevel(logging.INFO)

def lambda_handler(event, context):

    # Get variables from os
    api_gateway_url = os.environ['ApiGatewayURL']
    api_gateway_role_arn = os.environ['ApiGatewayRoleARN']
    api_gateway_role_name = os.environ['ApiGatewayRoleName']
    auto_ml_role_arn = os.environ['AutoMLRoleARN']
    auto_ml_role_name = os.environ['AutoMLRoleName']
    region_name = os.environ['Region']
    s3_bucket_name = os.environ['S3BucketName']
    secret_name = os.environ['SecretArn']
    kms_key_arn = os.environ['KmsKeyArn']
    vpc_security_group_ids = os.environ['VpcSecurityGroupIds']
    vpc_subnet_ids = os.environ['VpcSubnetIds']
    snowflake_role_name = os.environ['SnowflakeRole']
    stack_name = os.environ['StackName']
    database_name = os.environ['DatabaseName']
    schema_name = os.environ['SchemaName']

    logger.info("api_gateway_url: " + api_gateway_url)
    logger.info("api_gateway_role_arn: " + api_gateway_role_arn)
    logger.info("api_gateway_role_name: " + api_gateway_role_name)
    logger.info("auto_ml_role_arn: " + auto_ml_role_arn)
    logger.info("auto_ml_role_name: " + auto_ml_role_name)
    logger.info("region_name: " + region_name)
    logger.info("s3_bucket_name: " + s3_bucket_name)
    logger.info("secret_name: " + secret_name)
    logger.info("kms_key_arn: " + kms_key_arn)
    logger.info("vpc_security_group_ids: " + vpc_security_group_ids)
    logger.info("vpc_subnet_ids: " + vpc_subnet_ids)
    logger.info("snowflake_role_name: " + snowflake_role_name)
    logger.info("stack_name: " + stack_name)
    logger.info("database_name: " + database_name)
    logger.info("schema_name: " + schema_name)
    logger.info("Snowflake resource suffix: " + os.environ['SnowflakeResourceSuffix'])

    # Delete
    if event['RequestType'] == 'Delete':
        logger.info("No action for Delete. Exiting.")
        sendResponse(event, context, SUCCESS, EMPTY_RESPONSE_DATA)
        return

    # Get the information connection from Secrets Manager
    try:
        get_secret_value_response = get_secret_information(region_name, secret_name)
    except:
        sendResponse(event, context, FAILED, EMPTY_RESPONSE_DATA)
        return

    # Decrypted secret using the associated KMS CMK
    # Ensure the Secret is in String mode
    if 'SecretString' not in get_secret_value_response:
        logger.error("The Secret is not in String mode")
        sendResponse(event, context, FAILED, EMPTY_RESPONSE_DATA)
        return

    # Create Snowflake resource
    try:
        snowflake_connection = connect_to_snowflake(get_secret_value_response, snowflake_role_name)
        snowflake_cursor = snowflake_connection.cursor()

        snowflake_cursor.execute(("use database %s;") % (database_name))
        
        snowflake_cursor.execute(("use schema %s;") % (schema_name))

        storage_integration_name = "AWS_AUTOPILOT_STORAGE_INTEGRATION" + "_" + stack_name
        api_integration_name = "AWS_AUTOPILOT_API_INTEGRATION" + "_" + stack_name

        # Create Snowflake Integrations
        create_storage_integration(snowflake_cursor, storage_integration_name, auto_ml_role_arn, s3_bucket_name)
        create_api_integration(snowflake_cursor, api_integration_name, api_gateway_role_arn, api_gateway_url)
        create_external_functions(snowflake_cursor, api_integration_name, auto_ml_role_arn, api_gateway_url,
                                  s3_bucket_name, secret_name, storage_integration_name, snowflake_role_name,
                                  kms_key_arn, vpc_security_group_ids, vpc_subnet_ids)

        # Describe Snowflake integrations
        storage_integration_info = get_storage_integration_info_for_policy(snowflake_cursor, storage_integration_name)
        api_integration_info = get_api_integration_info_for_policy(snowflake_cursor, api_integration_name)
    except Exception as e:
        logger.exception('Problem running SQL statements: ' + str(e))
        responseData = {'Failed': 'Unable to execute SQL statements in Snowflake'}
        sendResponse(event, context, FAILED, responseData)
        return
    finally:
        if 'snowflake_cursor' in vars():
            snowflake_cursor.close()
        if 'snowflake_connection' in vars():
            snowflake_connection.close()

    # Update IAM role to add Snowflake information
    logger.info("Updating IAM Role")
    storage_integration_policy_str = create_policy_string(storage_integration_info)
    api_integration_policy_str = create_policy_string(api_integration_info)

    try:
        update_assume_role_policy(storage_integration_policy_str, auto_ml_role_name)
        update_assume_role_policy(api_integration_policy_str, api_gateway_role_name)
    except Exception as e:
        logger.exception('Problem updating assume role policy: ' + str(e))
        responseData = {'Failed': 'There was a problem updating the assume role policies'}
        sendResponse(event, context, FAILED, responseData)
        return

    responseData = {'Success': 'Snowflake resources created.'}
    sendResponse(event, context, SUCCESS, responseData)
    logger.info("Success")

def get_secret_information(region_name, secret_name):
    logger.info("Getting secret information")
    try:
        secretsmanager = boto3.client('secretsmanager')

        return secretsmanager.get_secret_value(
            SecretId=secret_name
        )
    except ClientError as e:
        if e.response['Error']['Code'] == 'ResourceNotFoundException':
            logger.exception("The requested secret " + secret_name + " was not found")
        else:
            logger.exception(e)
        raise e

def connect_to_snowflake(get_secret_value_response, snowflake_role_name):
    secret_string = get_secret_value_response['SecretString']

    secret = json.loads(secret_string)
    snowflake_account = secret['accountid']
    snowflake_password = secret['password']
    snowflake_userName = secret['username']

    # Connect to Snowflake
    logger.info("Connecting to Snowflake")
    snowflake_connection = snowflake.connector.connect(
        user=snowflake_userName,
        password=snowflake_password,
        account=snowflake_account,
        role=snowflake_role_name
    )

    return snowflake_connection

def sendResponse(event, context, responseStatus, responseData):
    responseBody = {'Status': responseStatus,
                    'Reason': 'See the details in CloudWatch Log Stream: ' + context.log_stream_name,
                    'PhysicalResourceId': context.log_stream_name,
                    'StackId': event['StackId'],
                    'RequestId': event['RequestId'],
                    'LogicalResourceId': event['LogicalResourceId'],
                    'Data': responseData}
    req = requests.put(event['ResponseURL'], data=json.dumps(responseBody))
    if req.status_code != 200:
        raise Exception('Received a non-200 HTTP response while sending response to CloudFormation.')
    return

def create_storage_integration(snowflake_cursor, storage_integration_name, auto_ml_role_arn, s3_bucket_name):
    logger.info("Creating Storage Integration [storage_integration_name=%s, auto_ml_role_arn=%s, s3_bucket_name=%s]",
                storage_integration_name, auto_ml_role_arn, s3_bucket_name)

    storage_integration_str = ("create or replace storage integration \"%s\" \
    type = external_stage \
    storage_provider = s3 \
    enabled = true \
    storage_aws_role_arn = '%s' \
    storage_allowed_locations = ('s3://%s')") % (storage_integration_name, auto_ml_role_arn, s3_bucket_name)

    snowflake_cursor.execute(storage_integration_str)

def create_api_integration(snowflake_cursor, api_integration_name, api_gateway_role_arn, api_gateway_url):
    logger.info("Creating API Integration [api_integration_name=%s, api_gateway_role_arn=%s, api_gateway_url=%s]",
                api_integration_name, api_gateway_role_arn, api_gateway_url)

    api_integration_str = ("create or replace api integration \"%s\" \
    api_provider = aws_api_gateway \
    api_aws_role_arn = '%s' \
    api_allowed_prefixes = ('%s') \
    enabled = true \
    ") % (api_integration_name, api_gateway_role_arn, api_gateway_url)

    snowflake_cursor.execute(api_integration_str)


def create_external_functions(snowflake_cursor, api_integration_name, auto_ml_role_arn, api_gateway_url, s3_bucket_name,
                              secret_arn, storage_integration_name, snowflake_role_name,
                              kms_key_arn, vpc_security_group_ids, vpc_subnet_ids):
    create_createmodel_ef(snowflake_cursor, api_integration_name, api_gateway_url, secret_arn, s3_bucket_name,
                          storage_integration_name, auto_ml_role_arn, snowflake_role_name,
                          kms_key_arn, vpc_security_group_ids, vpc_subnet_ids)

def create_createmodel_ef(snowflake_cursor, api_integration_name, api_gateway_url, secret_arn, s3_bucket_name,
                          storage_integration_name, auto_ml_role_arn, snowflake_role_name,
                          kms_key_arn, vpc_security_group_ids, vpc_subnet_ids):
    logger.info(
        "Creating External function: AWS_AUTOPILOT_CREATE_MODEL [api_integration_name=%s, api_gateway_url=%s, secret_arn=%s, s3_bucket_name=%s, storage_integration_name=%s, auto_ml_role_arn=%s, snowflake_role_name=%s, kms_key_arn=%s, vpc_security_group_ids=%s, vpc_subnet_ids=%s]",
        api_integration_name, api_gateway_url, secret_arn, s3_bucket_name, storage_integration_name, auto_ml_role_arn,
        snowflake_role_name, kms_key_arn, vpc_security_group_ids, vpc_subnet_ids)

    vpc_security_group_ids_with_quotes = add_quotes_to_comma_delimited_list_items(vpc_security_group_ids)
    vpc_subnet_ids_with_quotes = add_quotes_to_comma_delimited_list_items(vpc_subnet_ids)
    logger.info("vpc_security_group_ids_with_quotes = %s, vpc_subnet_ids_with_quotes = %s", vpc_security_group_ids_with_quotes, vpc_subnet_ids_with_quotes)

    createmodel_request_translator_str = ("""create or replace function %s(EVENT OBJECT) 
        returns OBJECT LANGUAGE JAVASCRIPT AS 
        $$ 
        let modelname = EVENT.body.data[0][1]; 
        let targetTable = EVENT.body.data[0][2]; 
        let targetCol = EVENT.body.data[0][3]; 
        let maxRunningTime = 24*60*60; 
        let deployModel = true;
        let modelEndpointTTL = 7*24*60*60; 
        let problemType; 
        let objectiveMetric;
        let maxCandidates; 
        
        if (EVENT.body.data[0].length == 10) { 
            if (EVENT.body.data[0][4] != undefined) { 
                objectiveMetric = EVENT.body.data[0][4]; 
            }
            
            if (EVENT.body.data[0][5] != undefined) { 
                problemType = EVENT.body.data[0][5]; 
            } 
            
            if (EVENT.body.data[0][6] != undefined) { 
                maxCandidates = EVENT.body.data[0][6]; 
            } 
            
            if (EVENT.body.data[0][7] != undefined) { 
                maxRunningTime = EVENT.body.data[0][7]; 
            }

            if (EVENT.body.data[0][8] != undefined) { 
                deployModel = EVENT.body.data[0][8]; 
            } 
            
            if (EVENT.body.data[0][9] != undefined) { 
                modelEndpointTTL = EVENT.body.data[0][9]; 
            } 
        } 
        
        let contextHeaders = EVENT.contextHeaders; 
        let jobDatasetsPath = modelname + \"-job/datasets/\" ; 
        let databaseName = contextHeaders[\"sf-context-current-database\"]; 
        let schemaName = contextHeaders[\"sf-context-current-schema\"]; 
        let tableNameComponents = targetTable.split(\".\"); 
        let s3OutputUri = \"s3://%s/output/\"; 
        let kmsKeyArn = \"%s\"; 
        let vpcSecurityGroupIds = [%s]; 
        let vpcSubnetIds = [%s];
        if (tableNameComponents.length === 3) 
        {
            databaseName = tableNameComponents[0]; 
            schemaName = tableNameComponents[1]; 
            targetTable = tableNameComponents[2];

        } else if (tableNameComponents.length === 2) 
        { 
            schemaName = tableNameComponents[0];
            targetTable = tableNameComponents[1];
        }
        
        let payload = { 
            \"AutoMLJobConfig\": { 
            \"CompletionCriteria\": { 
                \"MaxAutoMLJobRuntimeInSeconds\": maxRunningTime 
            } 
            }, 
            \"AutoMLJobName\": modelname + \"-job\", 
            \"InputDataConfig\": [
            {
                \"TargetAttributeName\": targetCol.toUpperCase(),
                \"AutoMLDatasetDefinition\": {
                \"AutoMLSnowflakeDatasetDefinition\": {
                    \"Warehouse\": contextHeaders[\"sf-context-current-warehouse\"],
                    \"Database\": databaseName,
                    \"Schema\": schemaName,
                    \"TableName\": targetTable,
                    \"SnowflakeRole\": \"%s\",
                    \"SecretArn\": \"%s\",
                    \"OutputS3Uri\": s3OutputUri + jobDatasetsPath,
                    \"StorageIntegration\": \"%s\"
                }
                }
            }
            ],
            \"OutputDataConfig\": {
            \"S3OutputPath\": s3OutputUri
            },
            \"RoleArn\": \"%s\"
        };
        
        if (objectiveMetric) { 
            payload[\"AutoMLJobObjective\"] = { 
                \"MetricName\": objectiveMetric
            };
        }
        if (problemType) { 
            payload[\"ProblemType\"] = problemType;
        }
        if (kmsKeyArn) { 
            payload[\"OutputDataConfig\"][\"KmsKeyId\"] = kmsKeyArn; 
            payload[\"InputDataConfig\"][\"AutoMLSnowflakeDatasetDefinition\"] = { 
                \"KmsKeyId\" : kmsKeyArn 
            }; 
            payload[\"AutoMLJobConfig\"][\"SecurityConfig\"] = payload[\"AutoMLJobConfig\"][\"SecurityConfig\"] || {}; 
            payload[\"AutoMLJobConfig\"][\"SecurityConfig\"] = { 
                \"VolumeKmsKeyId\": kmsKeyArn, 
                \"EnableInterContainerTrafficEncryption\": true 
            }; 
        } 
        if (vpcSecurityGroupIds.length > 0) { 
            payload[\"AutoMLJobConfig\"][\"SecurityConfig\"] = payload[\"AutoMLJobConfig\"][\"SecurityConfig\"] || {}; 
            payload[\"AutoMLJobConfig\"][\"SecurityConfig\"][\"VpcConfig\"] = payload[\"AutoMLJobConfig\"][\"SecurityConfig\"][\"VpcConfig\"] || {}; 
            payload[\"AutoMLJobConfig\"][\"SecurityConfig\"][\"VpcConfig\"][\"SecurityGroupIds\"] = vpcSecurityGroupIds; 
        } 
        if (vpcSubnetIds.length > 0) { 
            payload[\"AutoMLJobConfig\"][\"SecurityConfig\"] = payload[\"AutoMLJobConfig\"][\"SecurityConfig\"] || {}; 
            payload[\"AutoMLJobConfig\"][\"SecurityConfig\"][\"VpcConfig\"] = payload[\"AutoMLJobConfig\"][\"SecurityConfig\"][\"VpcConfig\"] || {}; 
            payload[\"AutoMLJobConfig\"][\"SecurityConfig\"][\"VpcConfig\"][\"Subnets\"] = vpcSubnetIds; 
        } 

        if(deployModel) {
            payload[\"ModelDeployConfig\"] ={ 
                \"ModelDeployMode\": \"Endpoint\",
                \"EndpointConfigDefinitions\": [
                {
                    \"EndpointConfigName\":  modelname + \"-m5-4xl-2\",
                    \"InitialInstanceCount\": 2,
                    \"InstanceType\": \"ml.m5.4xlarge\"
                }
                ],
                \"EndpointDefinitions\": [
                {
                    \"EndpointName\": modelname,
                    \"EndpointConfigName\": modelname + \"-m5-4xl-2\",
                    \"DeletionCondition\": {
                    \"MaxRuntimeInSeconds\": modelEndpointTTL
                    }
                }
                ]
            };
        }

        if (maxCandidates) {
            payload[\"AutoMLJobConfig\"][\"CompletionCriteria\"][\"MaxCandidates\"] = maxCandidates;
        }
        
        return {\"body\": JSON.stringify(payload)}; 
        $$;""") % (add_snowflake_resource_suffix("AWS_AUTOPILOT_CREATE_MODEL_REQUEST_TRANSLATOR"), s3_bucket_name, kms_key_arn, vpc_security_group_ids_with_quotes, vpc_subnet_ids_with_quotes, snowflake_role_name, secret_arn, storage_integration_name, auto_ml_role_arn)

    snowflake_cursor.execute(createmodel_request_translator_str)

    createmodel_response_translator_str = ("""create or replace function %s(EVENT OBJECT) 
        returns OBJECT LANGUAGE JAVASCRIPT AS 
        $$ 
        let arn = EVENT.body.AutoMLJobArn; 
        let message = \"Model creation in progress. Job ARN = \" + arn; 
        return {\"body\": {   \"data\" : [[0, message]]  }} 
        $$;""") %  (add_snowflake_resource_suffix("AWS_AUTOPILOT_CREATE_MODEL_RESPONSE_TRANSLATOR"))

    snowflake_cursor.execute(createmodel_response_translator_str)

    create_createmodel_ef_str = ("""create or replace external function %s(modelname varchar, targettable varchar, targetcol varchar) 
    returns variant 
    api_integration = \"%s\" 
    context_headers  = (CURRENT_DATABASE, CURRENT_SCHEMA, CURRENT_WAREHOUSE) 
    request_translator = %s 
    response_translator=%s 
    max_batch_rows=1 
    as '%s/createmodel';""") % (add_snowflake_resource_suffix("AWS_AUTOPILOT_CREATE_MODEL"), api_integration_name, get_full_resource_name_with_suffix("AWS_AUTOPILOT_CREATE_MODEL_REQUEST_TRANSLATOR"), get_full_resource_name_with_suffix("AWS_AUTOPILOT_CREATE_MODEL_RESPONSE_TRANSLATOR"), api_gateway_url)

    snowflake_cursor.execute(create_createmodel_ef_str)

    create_createmodel_ef_str2 = ("""create or replace external function %s(modelname varchar, targettable varchar, 
    targetcol varchar, objectiveMetric varchar, problemType varchar, maxCandidates integer, maxRunningTime integer, deployModel boolean, modelEndpointTTL integer) 
    returns variant 
    api_integration = \"%s\" 
    context_headers  = (CURRENT_DATABASE, CURRENT_SCHEMA, CURRENT_WAREHOUSE) 
    request_translator = %s 
    response_translator=%s 
    max_batch_rows=1 
    as '%s/createmodel';""") % (add_snowflake_resource_suffix("AWS_AUTOPILOT_CREATE_MODEL"), api_integration_name, get_full_resource_name_with_suffix("AWS_AUTOPILOT_CREATE_MODEL_REQUEST_TRANSLATOR"), get_full_resource_name_with_suffix("AWS_AUTOPILOT_CREATE_MODEL_RESPONSE_TRANSLATOR"), api_gateway_url)

    snowflake_cursor.execute(create_createmodel_ef_str2)


def get_storage_integration_info_for_policy(snowflake_cursor, storage_integration_name):
    logger.info("Describing Storage Integration")
    storage_user_arn = ''
    storage_external_id = ''

    snowflake_cursor.execute(("describe integration \"%s\"") % (storage_integration_name))
    rows = snowflake_cursor.fetchall()
    for row in rows:
        value = list(row)
        if (value[0] == "STORAGE_AWS_IAM_USER_ARN"):
            storage_user_arn = value[2]
        if (value[0] == "STORAGE_AWS_EXTERNAL_ID"):
            storage_external_id = value[2]
    return {
        SERVICE: "sagemaker.amazonaws.com",
        USER_ARN: storage_user_arn,
        EXTERNAL_ID: storage_external_id
    }

def get_api_integration_info_for_policy(snowflake_cursor, api_integration_name):
    logger.info("Describing API Integration")
    storage_user_arn = ''
    storage_external_id = ''

    snowflake_cursor.execute(("describe integration \"%s\"") % (api_integration_name))
    rows = snowflake_cursor.fetchall()
    for row in rows:
        value = list(row)
        if (value[0] == "API_AWS_IAM_USER_ARN"):
            api_user_arn = value[2]
        if (value[0] == "API_AWS_EXTERNAL_ID"):
            api_external_id = value[2]
    return {
        SERVICE: "apigateway.amazonaws.com",
        USER_ARN: api_user_arn,
        EXTERNAL_ID: api_external_id
    }

def create_policy_string(integration_info):
    policy_json = {
      "Version": "2012-10-17",
      "Statement":[
        {
          "Effect": "Allow",
          "Principal": {"Service":[integration_info[SERVICE]]},
          "Action": "sts:AssumeRole"
        },
        {
          "Effect": "Allow",
          "Principal": {
            "AWS":[integration_info[USER_ARN]]
          },
          "Action": "sts:AssumeRole",
          "Condition": {
            "StringEquals": {
              "sts:ExternalId": integration_info[EXTERNAL_ID]
            }
          }
        }
      ]
    }
    return json.dumps(policy_json)

def update_assume_role_policy(policy_str, role_name):
    logger.info('Updating assume role policy for role: ' + role_name)
    logger.info('Policy used: ' + policy_str)
    iam = boto3.client('iam')
    iam.update_assume_role_policy(
        PolicyDocument=policy_str,
        RoleName=role_name
    )

def add_quotes_to_comma_delimited_list_items(comma_delimited_list: str):
    if comma_delimited_list:
        items = comma_delimited_list.replace(" ", "").split(",")
        comma_delimited_list_with_quotes = ', '.join('"' + item + '"' for item in items)
    else:
        comma_delimited_list_with_quotes = ''
    return comma_delimited_list_with_quotes

def add_snowflake_resource_suffix(resource_name: str):
    suffix = os.environ['SnowflakeResourceSuffix']

    if suffix and suffix.strip() :
        return resource_name + "_" + suffix
    
    return resource_name


def get_full_resource_name_with_suffix(resource_name: str):
    database_name = os.environ['DatabaseName']
    schema_name = os.environ['SchemaName']
    resource_name_with_suffix = add_snowflake_resource_suffix(resource_name)
    return database_name + "." + schema_name + "." + resource_name_with_suffix
